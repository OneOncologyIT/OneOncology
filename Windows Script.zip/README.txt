To run LBMC's Windows Data Gathering Script against the local systems do the following:

1. Ensure the user you are running this script from is an admin on all systems to gather data from

2. Right Click on the "FISMA_BatchFilev4-local" File and click "Run as Administrator".  

3. Once all windows close the script is complete, usually 3-6 minutes.

4. Zip the output file directorie up and send them to LBMC.